document.addEventListener('DOMContentLoaded', function() {
    const chelseyImage = document.querySelector('.chelseyImage');

    //Functions to fade pic in and out
    function fadeIn() {
        chelseyImage.style.transition = 'opacity 2s ease-in-out';
        chelseyImage.style.opacity = '1';
    }

    
    function fadeOut() {
        chelseyImage.style.transition = 'opacity 2s ease-in-out';
        chelseyImage.style.opacity = '0';
    }

    
    document.getElementById('headerTitle').addEventListener('click', function(event) {
        event.preventDefault(); 
        fadeIn(); 
        setTimeout(fadeOut, 5000); 
    });

    //Audio player script
    const toggleButton = document.getElementById('toggleAudioPlayer');
    const audioPlayer = document.getElementById('audioPlayer');

    toggleButton.addEventListener('click', function() {
        if (audioPlayer.style.display === 'none') {
            audioPlayer.style.display = 'block'; // Show the audio player
        } else {
            audioPlayer.style.display = 'none'; // Hide the audio player
        }
    });

    
    const audio = document.getElementById('backgroundMusic');
    const playButton = document.getElementById('playButton');
    const pauseButton = document.getElementById('pauseButton');
    const volumeSlider = document.getElementById('volumeSlider');

    
    playButton.addEventListener('click', function() {
        audio.play();
    });

    
    pauseButton.addEventListener('click', function() {
        audio.pause();
    });

    
    volumeSlider.addEventListener('input', function() {
        audio.volume = volumeSlider.value / 100;
    });
});
