document.addEventListener('DOMContentLoaded', function() {
    const data = {
        "images": [
            "./Arraypics/Videogame.png",
            "./Arraypics/pythonreport.png",
            "./Arraypics/js.png",
            "./Arraypics/Gallery.png",
            "./Arraypics/WebsiteHeader.png",
            "./Arraypics/pythonreport2.png",
            "./Arraypics/ERD.png"
        ]
    };

    const images = data.images;
    const slideshow = document.querySelector('.slideshow');

    images.forEach(imagePath => {
        const img = document.createElement('img');
        img.src = imagePath;
        img.alt = 'Slideshow Image';
        img.style.width = '500px'; 
        img.style.height = '500px';
        img.style.display = 'none'; 
        slideshow.appendChild(img);
    });

    let currentIndex = 0;

    function showImage() {
        const images = slideshow.querySelectorAll('img');
        images.forEach((img, index) => {
            if (index === currentIndex) {
                img.style.display = 'block';
            } else {
                img.style.display = 'none';
            }
        });
        currentIndex = (currentIndex + 1) % images.length; 
    }

    showImage();

    setInterval(showImage, 3000);
});
